-- Truck Tracking Command Center V5.1 - Owner Access Control
-- Run AFTER SUPABASE_V4_SETUP.sql / V5 base setup.
-- First signed-in owner who opens the V5.1 dashboard can bootstrap as MAIN ADMIN.
-- Later users sign up with their own email/password and claim a one-time access code.

create extension if not exists pgcrypto;

create table if not exists public.fleet_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  role text not null default 'viewer' check (role in ('admin','manager','viewer')),
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.fleet_user_trucks (
  user_id uuid not null references public.fleet_profiles(user_id) on delete cascade,
  truck_id text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, truck_id)
);
create index if not exists fleet_user_trucks_truck_idx on public.fleet_user_trucks(truck_id);

create table if not exists public.fleet_invites (
  id uuid primary key default gen_random_uuid(),
  code_hash text not null unique,
  role text not null check (role in ('manager','viewer')),
  created_by uuid not null references auth.users(id) on delete cascade,
  expires_at timestamptz not null default (now() + interval '72 hours'),
  max_uses integer not null default 1 check (max_uses between 1 and 100),
  uses integer not null default 0,
  active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.fleet_invite_trucks (
  invite_id uuid not null references public.fleet_invites(id) on delete cascade,
  truck_id text not null,
  primary key(invite_id,truck_id)
);

alter table public.fleet_profiles enable row level security;
alter table public.fleet_user_trucks enable row level security;
alter table public.fleet_invites enable row level security;
alter table public.fleet_invite_trucks enable row level security;

create or replace function public.fleet_is_admin()
returns boolean language sql stable security definer set search_path=public as $$
  select exists(select 1 from public.fleet_profiles p where p.user_id=auth.uid() and p.active and p.role='admin');
$$;

create or replace function public.fleet_can_access_truck(p_truck_id text)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from public.fleet_profiles p
    where p.user_id=auth.uid() and p.active and (
      p.role='admin' or exists(select 1 from public.fleet_user_trucks ut where ut.user_id=p.user_id and ut.truck_id=p_truck_id)
    )
  );
$$;

create or replace function public.fleet_can_manage_truck(p_truck_id text)
returns boolean language sql stable security definer set search_path=public as $$
  select exists(
    select 1 from public.fleet_profiles p
    where p.user_id=auth.uid() and p.active and (
      p.role='admin' or (p.role='manager' and exists(select 1 from public.fleet_user_trucks ut where ut.user_id=p.user_id and ut.truck_id=p_truck_id))
    )
  );
$$;

create or replace function public.fleet_my_access()
returns jsonb language plpgsql security definer set search_path=public as $$
declare p public.fleet_profiles; ids text[];
begin
  select * into p from public.fleet_profiles where user_id=auth.uid();
  if p.user_id is null then return jsonb_build_object('ok',false,'has_access',false); end if;
  select coalesce(array_agg(truck_id order by truck_id),array[]::text[]) into ids from public.fleet_user_trucks where user_id=auth.uid();
  return jsonb_build_object('ok',true,'has_access',p.active,'role',p.role,'display_name',coalesce(p.display_name,''),'truck_ids',ids);
end $$;

create or replace function public.fleet_bootstrap_admin()
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  if exists(select 1 from public.fleet_profiles) then return jsonb_build_object('ok',false,'message','Main admin already exists'); end if;
  insert into public.fleet_profiles(user_id,role,active) values(auth.uid(),'admin',true);
  return jsonb_build_object('ok',true,'role','admin');
end $$;

create or replace function public.fleet_create_invite(p_role text, p_truck_ids text[], p_expires_hours integer default 72)
returns jsonb language plpgsql security definer set search_path=public as $$
declare c text; inv uuid;
begin
  if not public.fleet_is_admin() then raise exception 'Main admin only'; end if;
  if p_role not in ('manager','viewer') then raise exception 'Invalid role'; end if;
  if coalesce(array_length(p_truck_ids,1),0)=0 then raise exception 'Select at least one truck'; end if;
  c := upper(substr(encode(gen_random_bytes(8),'hex'),1,10));
  insert into public.fleet_invites(code_hash,role,created_by,expires_at)
  values(encode(digest(c,'sha256'),'hex'),p_role,auth.uid(),now()+make_interval(hours=>greatest(1,least(coalesce(p_expires_hours,72),720)))) returning id into inv;
  insert into public.fleet_invite_trucks(invite_id,truck_id) select inv,unnest(p_truck_ids);
  return jsonb_build_object('ok',true,'code',c,'role',p_role,'expires_at',(now()+make_interval(hours=>greatest(1,least(coalesce(p_expires_hours,72),720)))));
end $$;

create or replace function public.fleet_claim_invite(p_code text, p_display_name text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare inv public.fleet_invites;
begin
  if auth.uid() is null then raise exception 'Sign in first'; end if;
  select * into inv from public.fleet_invites
  where code_hash=encode(digest(upper(trim(p_code)),'sha256'),'hex') and active and expires_at>now() and uses<max_uses
  order by created_at desc limit 1;
  if inv.id is null then return jsonb_build_object('ok',false,'message','Invalid or expired access code'); end if;
  insert into public.fleet_profiles(user_id,display_name,role,active)
  values(auth.uid(),nullif(trim(p_display_name),''),inv.role,true)
  on conflict(user_id) do update set display_name=coalesce(excluded.display_name,public.fleet_profiles.display_name),role=excluded.role,active=true;
  delete from public.fleet_user_trucks where user_id=auth.uid();
  insert into public.fleet_user_trucks(user_id,truck_id)
  select auth.uid(),truck_id from public.fleet_invite_trucks where invite_id=inv.id;
  update public.fleet_invites set uses=uses+1,active=(uses+1<max_uses) where id=inv.id;
  return jsonb_build_object('ok',true,'role',inv.role);
end $$;

create or replace function public.fleet_list_members()
returns table(user_id uuid,email text,display_name text,role text,active boolean,truck_ids text[])
language sql security definer set search_path=public,auth as $$
  select p.user_id,u.email,p.display_name,p.role,p.active,
         coalesce((select array_agg(ut.truck_id order by ut.truck_id) from public.fleet_user_trucks ut where ut.user_id=p.user_id),array[]::text[])
  from public.fleet_profiles p join auth.users u on u.id=p.user_id
  where public.fleet_is_admin()
  order by p.created_at;
$$;

create or replace function public.fleet_set_member_trucks(p_user_id uuid,p_truck_ids text[])
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if not public.fleet_is_admin() then raise exception 'Main admin only'; end if;
  if not exists(select 1 from public.fleet_profiles where user_id=p_user_id and role<>'admin') then raise exception 'Member not found'; end if;
  delete from public.fleet_user_trucks where user_id=p_user_id;
  insert into public.fleet_user_trucks(user_id,truck_id) select p_user_id,unnest(coalesce(p_truck_ids,array[]::text[]));
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.fleet_set_member_active(p_user_id uuid,p_active boolean)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
  if not public.fleet_is_admin() then raise exception 'Main admin only'; end if;
  update public.fleet_profiles set active=p_active where user_id=p_user_id and role<>'admin';
  return jsonb_build_object('ok',true);
end $$;

create or replace function public.fleet_get_device_tokens()
returns table(truck_id text,device_token uuid,pairing_code text)
language sql security definer set search_path=public as $$
  select d.truck_id,d.device_token,d.pairing_code from public.truck_device_tokens d
  where public.fleet_can_manage_truck(d.truck_id);
$$;

-- Replace broad owner policies from V4 with per-user fleet access.
do $$ declare r record; begin
  for r in select policyname,tablename from pg_policies where schemaname='public' and tablename in ('Truck','trips','location_history','geofences','geofence_state','alerts','truck_device_tokens','fleet_profiles','fleet_user_trucks','fleet_invites','fleet_invite_trucks') loop
    execute format('drop policy if exists %I on public.%I',r.policyname,r.tablename);
  end loop;
end $$;

-- Profiles / mappings.
create policy "profile self read" on public.fleet_profiles for select to authenticated using (user_id=auth.uid() or public.fleet_is_admin());
create policy "admin profiles manage" on public.fleet_profiles for all to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());
create policy "user truck access read" on public.fleet_user_trucks for select to authenticated using (user_id=auth.uid() or public.fleet_is_admin());
create policy "admin user truck manage" on public.fleet_user_trucks for all to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());
create policy "admin invite manage" on public.fleet_invites for all to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());
create policy "admin invite trucks manage" on public.fleet_invite_trucks for all to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());

-- Truck master: everyone only sees assigned trucks; only main admin edits truck master.
create policy "fleet truck read" on public."Truck" for select to authenticated using (public.fleet_can_access_truck(id::text));
create policy "fleet truck insert admin" on public."Truck" for insert to authenticated with check (public.fleet_is_admin());
create policy "fleet truck update admin" on public."Truck" for update to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());
create policy "fleet truck delete admin" on public."Truck" for delete to authenticated using (public.fleet_is_admin());

-- Trips: manager can manage only assigned trucks; viewer read only.
create policy "fleet trips read" on public.trips for select to authenticated using (public.fleet_can_access_truck(truck_id));
create policy "fleet trips insert" on public.trips for insert to authenticated with check (public.fleet_can_manage_truck(truck_id));
create policy "fleet trips update" on public.trips for update to authenticated using (public.fleet_can_manage_truck(truck_id)) with check (public.fleet_can_manage_truck(truck_id));
create policy "fleet trips delete" on public.trips for delete to authenticated using (public.fleet_is_admin());

create policy "fleet locations read" on public.location_history for select to authenticated using (public.fleet_can_access_truck(truck_id));
create policy "fleet alerts read" on public.alerts for select to authenticated using (public.fleet_can_access_truck(truck_id));
create policy "fleet alerts update" on public.alerts for update to authenticated using (public.fleet_can_manage_truck(truck_id)) with check (public.fleet_can_manage_truck(truck_id));
create policy "fleet geofence state read" on public.geofence_state for select to authenticated using (public.fleet_can_access_truck(truck_id));

-- Geofences are fleet-level: active users can read; main admin manages.
create policy "fleet geofences read" on public.geofences for select to authenticated using (exists(select 1 from public.fleet_profiles p where p.user_id=auth.uid() and p.active));
create policy "fleet geofences admin insert" on public.geofences for insert to authenticated with check (public.fleet_is_admin());
create policy "fleet geofences admin update" on public.geofences for update to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());
create policy "fleet geofences admin delete" on public.geofences for delete to authenticated using (public.fleet_is_admin());

-- Device tokens never exposed through direct table SELECT; authorized managers get only their tokens through RPC.
create policy "device token admin only" on public.truck_device_tokens for all to authenticated using (public.fleet_is_admin()) with check (public.fleet_is_admin());

grant execute on function public.fleet_my_access() to authenticated;
grant execute on function public.fleet_bootstrap_admin() to authenticated;
grant execute on function public.fleet_create_invite(text,text[],integer) to authenticated;
grant execute on function public.fleet_claim_invite(text,text) to authenticated;
grant execute on function public.fleet_list_members() to authenticated;
grant execute on function public.fleet_set_member_trucks(uuid,text[]) to authenticated;
grant execute on function public.fleet_set_member_active(uuid,boolean) to authenticated;
grant execute on function public.fleet_get_device_tokens() to authenticated;
