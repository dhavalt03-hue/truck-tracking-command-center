-- Truck Tracking Command Center V5.2 — 100 Truck Scale Upgrade
-- Run AFTER the existing V4/V5 access SQL. Safe to run more than once.
-- Adds indexes for a fleet target of up to 100 trucks and larger trip/location history.

create index if not exists truck_last_updated_idx on public."Truck" (last_updated desc);
create index if not exists truck_active_idx on public."Truck" (is_active);
create index if not exists trips_truck_status_created_idx on public.trips (truck_id, status, created_at desc);
create index if not exists trips_status_started_idx on public.trips (status, started_at desc);
create index if not exists location_history_truck_recorded_idx on public.location_history (truck_id, recorded_at desc);
create index if not exists location_history_trip_recorded_idx on public.location_history (trip_id, recorded_at asc);
create index if not exists alerts_truck_event_idx on public.alerts (truck_id, event_at desc);
create index if not exists alerts_ack_event_idx on public.alerts (acknowledged, event_at desc);
create index if not exists geofence_state_truck_idx on public.geofence_state (truck_id);
create index if not exists fleet_user_trucks_user_idx on public.fleet_user_trucks (user_id);

-- V5.2 remains role-based:
-- Main Admin can see all trucks.
-- Managers/Viewers only see assigned trucks through RLS.
-- This file changes scale/indexing only; it does not weaken access control.
