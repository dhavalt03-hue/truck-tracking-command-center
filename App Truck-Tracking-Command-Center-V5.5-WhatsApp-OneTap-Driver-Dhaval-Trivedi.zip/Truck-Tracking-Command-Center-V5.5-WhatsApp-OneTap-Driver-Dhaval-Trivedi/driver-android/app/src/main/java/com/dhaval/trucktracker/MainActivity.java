package com.dhaval.trucktracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
  private Button startBtn;
  private TextView status, truckText, helper;
  private Prefs prefs;
  private SupabaseApi api;
  private boolean startAfterPermission = false;

  @Override public void onCreate(Bundle b) {
    super.onCreate(b);
    setContentView(R.layout.activity_main);
    prefs = new Prefs(this);
    api = new SupabaseApi(this);
    startBtn = findViewById(R.id.startBtn);
    status = findViewById(R.id.statusText);
    truckText = findViewById(R.id.truckText);
    helper = findViewById(R.id.helperText);
    startBtn.setOnClickListener(v -> startTracking());
    handleIntent(getIntent());
    refreshUi();
  }

  @Override protected void onNewIntent(Intent intent) {
    super.onNewIntent(intent);
    setIntent(intent);
    handleIntent(intent);
    refreshUi();
  }

  private void handleIntent(Intent intent) {
    Uri d = intent == null ? null : intent.getData();
    if (d == null || !"trucktracker".equalsIgnoreCase(d.getScheme())) return;
    String truck = d.getQueryParameter("truck");
    String token = d.getQueryParameter("token");
    String no = d.getQueryParameter("no");
    if (truck != null && !truck.isEmpty() && token != null && !token.isEmpty()) {
      prefs.put("truck_id", truck);
      prefs.put("device_token", token);
      prefs.put("truck_no", no == null || no.isEmpty() ? "Assigned Truck" : no);
      prefs.putBool("tracking", false);
      prefs.putBool("desired_tracking", false);
      Toast.makeText(this, "Trip received from office", Toast.LENGTH_SHORT).show();
    }
  }

  private void refreshUi() {
    boolean assigned = !prefs.get("truck_id", "").isEmpty() && !prefs.get("device_token", "").isEmpty();
    boolean on = prefs.getBool("tracking", false);
    if (!assigned) {
      truckText.setText("NO TRIP ASSIGNED");
      helper.setText("Open the trip message sent by your office on WhatsApp. No login, password or truck selection is required.");
      startBtn.setVisibility(View.GONE);
      status.setText("Waiting for office trip link");
      status.setBackgroundColor(0xFF13233A);
      return;
    }
    truckText.setText(prefs.get("truck_no", "Assigned Truck"));
    startBtn.setVisibility(View.VISIBLE);
    if (on) {
      status.setText("● TRACKING ACTIVE\nYou can lock the phone");
      status.setBackgroundColor(0xFF103D2B);
      startBtn.setEnabled(false);
      startBtn.setText("✓  TRIP STARTED");
      helper.setText("Location is being sent to the Fleet Owner Command Center. Keep mobile data and Location ON.");
    } else {
      status.setText("Trip ready");
      status.setBackgroundColor(0xFF13233A);
      startBtn.setEnabled(true);
      startBtn.setText("▶  START TRIP");
      helper.setText("Tap START TRIP. On first use Android may ask for Location/notification permission. After that, the phone can be locked while tracking continues.");
    }
  }

  private boolean hasPermissions() {
    return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
      (Build.VERSION.SDK_INT < 33 || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED);
  }

  private boolean requestNeededPermissions() {
    List<String> req = new ArrayList<>();
    if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
      req.add(Manifest.permission.ACCESS_FINE_LOCATION);
    if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
      req.add(Manifest.permission.POST_NOTIFICATIONS);
    if (!req.isEmpty()) {
      requestPermissions(req.toArray(new String[0]), 22);
      return true;
    }
    return false;
  }

  @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
    super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    if (requestCode == 22) {
      if (hasPermissions() && startAfterPermission) {
        startAfterPermission = false;
        new Handler(Looper.getMainLooper()).postDelayed(this::startTracking, 300);
      } else if (!hasPermissions()) {
        Toast.makeText(this, "Location permission is required to track the trip", Toast.LENGTH_LONG).show();
      }
    }
  }

  private void startTracking() {
    String id = prefs.get("truck_id", "");
    String token = prefs.get("device_token", "");
    if (id.isEmpty() || token.isEmpty()) {
      Toast.makeText(this, "Open the WhatsApp trip link from your office first", Toast.LENGTH_LONG).show();
      return;
    }
    if (requestNeededPermissions()) {
      startAfterPermission = true;
      return;
    }
    startBtn.setEnabled(false);
    status.setText("Starting trip…");
    new Thread(() -> {
      try {
        org.json.JSONObject r = api.startTracking(id, token);
        if (!r.optBoolean("ok")) throw new Exception(r.optString("message", "Trip is not active in owner dashboard"));
        prefs.putFloat("distance", 0);
        prefs.put("last_lat", "");
        prefs.put("last_lon", "");
        prefs.put("trip_id", r.optString("trip_id", ""));
        prefs.putBool("desired_tracking", true);
        Intent s = new Intent(this, TrackingService.class)
          .putExtra("truck_id", id)
          .putExtra("truck_no", prefs.get("truck_no", "Truck"));
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
        prefs.putBool("tracking", true);
        runOnUiThread(() -> {
          refreshUi();
          Toast.makeText(this, "Trip started. Tracking is ON.", Toast.LENGTH_LONG).show();
        });
      } catch (Exception e) {
        runOnUiThread(() -> {
          refreshUi();
          Toast.makeText(this, "Could not start: " + e.getMessage(), Toast.LENGTH_LONG).show();
        });
      }
    }).start();
  }

  private void ensureServiceIfWanted() {
    if (!prefs.getBool("desired_tracking", false) || !hasPermissions()) return;
    String id = prefs.get("truck_id", ""), token = prefs.get("device_token", "");
    if (id.isEmpty() || token.isEmpty()) return;
    try {
      Intent s = new Intent(this, TrackingService.class)
        .putExtra("truck_id", id)
        .putExtra("truck_no", prefs.get("truck_no", "Truck"));
      if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
    } catch (Exception ignored) {}
  }

  @Override protected void onResume() {
    super.onResume();
    refreshUi();
    ensureServiceIfWanted();
  }
}
