TRUCK TRACKER DRIVER V4 — ANDROID

Driver workflow
1. Office creates/activates a trip in Owner Dashboard.
2. Office sends the generated WhatsApp trip link.
3. Driver taps the link. The app is assigned automatically (no username/password).
4. Driver taps START TRACKING once (permission prompts may appear on first use).
5. Driver can lock the phone; a foreground GPS notification remains visible.
6. Owner completes or cancels the trip from the web dashboard. The app stops after its next successful GPS check.

Manual fallback
- Driver can choose truck + enter the 6-digit pairing code shown in Owner Dashboard.
- Assignment is remembered on the phone.

Reliability setup (once per driver phone)
- Location = Allow while using / precise.
- Notifications = Allow.
- Mobile data = ON.
- Battery optimization: set this app to Unrestricted / Don't optimize when possible.
- Do not Force Stop the app during an active trip.

Build
Open driver-android in Android Studio OR use the included GitHub Actions workflow from the V4 ZIP.
Build > Build APK(s). Debug APK is for testing; use a signed release APK for long-term distribution.
