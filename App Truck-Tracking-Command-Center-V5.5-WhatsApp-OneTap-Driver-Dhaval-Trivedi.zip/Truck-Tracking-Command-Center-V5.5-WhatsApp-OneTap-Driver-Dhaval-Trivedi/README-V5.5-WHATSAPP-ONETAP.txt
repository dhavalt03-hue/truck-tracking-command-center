V5.5 DRIVER FLOW — WHATSAPP ONE-TAP

This version intentionally removes driver login, password, truck list, and manual pairing from the normal driver interface.

NORMAL DRIVER FLOW
1. Owner creates/activates a trip in Fleet Owner Command Center.
2. Owner taps WhatsApp for that active trip.
3. Driver receives the message and taps the trip link.
4. Android opens Truck Tracker Driver with the correct truck already assigned by the secure link.
5. Driver taps one large START TRIP button.
6. First use only: Android may request Location/notification permission.
7. Tracking runs as a foreground location service and can continue while the phone is locked.
8. Owner completes/cancels the trip in the Command Center. Driver does not choose trucks or close trips.

Opening the app directly without an office trip link shows only: Waiting for office trip link.
