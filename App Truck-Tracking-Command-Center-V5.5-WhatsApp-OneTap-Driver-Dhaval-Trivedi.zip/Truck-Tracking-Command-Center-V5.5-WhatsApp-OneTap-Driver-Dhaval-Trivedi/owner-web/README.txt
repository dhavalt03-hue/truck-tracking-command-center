OWNER WEB V4

Deploy BOTH files from owner-web to the same HTTPS site:
- index.html  -> secure owner dashboard
- driver.html -> WhatsApp/SMS driver-link landing page

For Cloudflare static assets, update the existing Worker with both files so your workers.dev link remains the same.
For a permanent business setup later, connect a subdomain such as tracking.yourdomain.com.

Run SUPABASE_V4_SETUP.sql before using V4.
