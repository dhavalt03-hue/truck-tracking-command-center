TRUCK TRACKING COMMAND CENTER V5 — RELIABLE MULTI-DAY FLEET TEST

Purpose
A practical up to 100-truck test system before paying for a commercial fleet platform.

V4 owner features
- Secure owner login
- Live fleet map
- Moving / stopped / offline status
- Speed, GPS accuracy, last update, trip KM
- Permanent truck master records with Edit / Archive / Reactivate (no history deletion)
- Planned / Active / Completed / Cancelled trips
- Owner-only trip completion/cancellation
- Start location + final destination
- Destination radius alert
- Long-stop alert and moving-again alert
- Geofence create/edit/enable/disable + enter/exit alerts
- Alert center + acknowledgement
- Trip route history on map
- WhatsApp/SMS driver assignment link
- Per-truck device token + backup pairing code

V4 driver flow
Office activates trip -> sends WhatsApp link -> driver taps link -> app is assigned automatically -> driver taps START TRACKING -> phone can lock.
Driver has NO email/password and NO End Trip button.
Owner completes/cancels the trip. On the next GPS server check, driver tracking stops.

Files
- SUPABASE_V4_SETUP.sql : run once in Supabase SQL Editor after your existing V3 setup
- owner-web/index.html : owner dashboard
- owner-web/driver.html : WhatsApp/SMS landing page that opens the Android app
- driver-android : Android V4 source
- github-workflow/build-driver-apk.yml : GitHub Actions workflow for phone-only APK builds
- TEST-CHECKLIST.txt : real-world accuracy/reliability test plan

Deployment
1. Run SUPABASE_V4_SETUP.sql once.
2. Deploy BOTH owner-web files to the same Cloudflare HTTPS site.
3. Upload Truck-Tracking-Command-Center-V4.zip to GitHub.
4. Replace the GitHub workflow with github-workflow/build-driver-apk.yml.
5. Download the successful APK artifact and install it on the test Android phone.
6. Use Owner Dashboard to add truck, create/activate trip, and send WhatsApp link.

Cost
You can test on free tiers first. Do not buy a map subscription yet. OpenStreetMap/Leaflet is used for the V4 test dashboard.

Production upgrades after accuracy testing
- Signed release APK
- Private GitHub repository / CI secrets
- Supabase Pro + backup policy
- Scheduled offline-alert engine
- Discord / email / push notification delivery
- Permanent custom domain (for example tracking.yourdomain.com)
- Owner roles/permissions if more staff are added


V5 reliability upgrade
- No automatic timeout while owner trip remains active
- Persistent desired_tracking state
- START_STICKY foreground GPS service
- Auto-resume attempt after Android reboot/package update
- Owner-complete/cancel remains the stop authority
- Background Location + Battery Unrestricted setup guidance
- See RELIABILITY-NOTES.txt before testing


V5.2 — 100 Truck Ready TWO-ACCOUNT ACCESS
=========================
- Bhudev = MAIN authorized account.
- Dhaval = SECOND authorized account.
- Both use their existing Supabase Auth email/password.
- No self-signup, invite code, Manager/Viewer, or additional-user workflow in owner-web.
- All operational V5.2 tracking features remain in the package.
- See ACCOUNT-ACCESS-V5.2-SIMPLIFIED.txt.


BRANDING
Made by Dhaval Trivedi
