-- Fleet Owner Command Center V5.3
-- One-time access policy helper for the two authorized owner accounts.
-- Does not delete truck/trip/GPS data.

-- MAIN Bhudev: 875d824c-9ca9-4491-a91a-cf30fe572da1
-- SECOND Dhaval: fb5801a8-4154-4d7f-a24f-52f70dc03a16

-- Truck full owner access (the app now includes Edit / Archive / Stop / Delete controls).
drop policy if exists "v5_3 two account truck manage" on public."Truck";
create policy "v5_3 two account truck manage"
on public."Truck"
for all to authenticated
using (auth.uid() in (
  '875d824c-9ca9-4491-a91a-cf30fe572da1'::uuid,
  'fb5801a8-4154-4d7f-a24f-52f70dc03a16'::uuid
))
with check (auth.uid() in (
  '875d824c-9ca9-4491-a91a-cf30fe572da1'::uuid,
  'fb5801a8-4154-4d7f-a24f-52f70dc03a16'::uuid
));

-- Helper policies for tables used directly by the owner interface.
do $$
begin
  if to_regclass('public.trips') is not null then
    execute 'drop policy if exists "v5_3 two account trips manage" on public.trips';
    execute 'create policy "v5_3 two account trips manage" on public.trips for all to authenticated using (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid)) with check (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid))';
  end if;
  if to_regclass('public.geofences') is not null then
    execute 'drop policy if exists "v5_3 two account geofence manage" on public.geofences';
    execute 'create policy "v5_3 two account geofence manage" on public.geofences for all to authenticated using (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid)) with check (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid))';
  end if;
  if to_regclass('public.alerts') is not null then
    execute 'drop policy if exists "v5_3 two account alerts manage" on public.alerts';
    execute 'create policy "v5_3 two account alerts manage" on public.alerts for all to authenticated using (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid)) with check (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid))';
  end if;
  if to_regclass('public.truck_device_tokens') is not null then
    execute 'drop policy if exists "v5_3 two account token manage" on public.truck_device_tokens';
    execute 'create policy "v5_3 two account token manage" on public.truck_device_tokens for all to authenticated using (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid)) with check (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid))';
  end if;
  if to_regclass('public.truck_access') is not null then
    execute 'drop policy if exists "v5_3 two account access manage" on public.truck_access';
    execute 'create policy "v5_3 two account access manage" on public.truck_access for all to authenticated using (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid)) with check (auth.uid() in (''875d824c-9ca9-4491-a91a-cf30fe572da1''::uuid,''fb5801a8-4154-4d7f-a24f-52f70dc03a16''::uuid))';
  end if;
end $$;
