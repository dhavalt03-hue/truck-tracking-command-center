TRUCK TRACKING COMMAND CENTER V5.2 — 100 TRUCK READY

Target fleet size: up to 100 trucks.

What changed from the earlier 2–20 truck target:
- Owner dashboard branding updated for 100-truck fleet use.
- Larger recent trip and alert fetch windows for fleet operations.
- Database scale indexes added in SUPABASE_V5_2_100_TRUCK_SCALE.sql.
- Access-code schema ceiling expanded to 100 uses (codes still default to one-time use).
- Existing Admin / Manager / Viewer truck-level privacy is preserved.
- Driver Android reliability/background tracking code is unchanged.

IMPORTANT:
This is engineered as a 100-truck-ready target, but production use should still be load-tested with real GPS traffic before placing all 100 trucks on it. For long-term history, use retention/archiving rather than loading every raw GPS point into the dashboard at once.
