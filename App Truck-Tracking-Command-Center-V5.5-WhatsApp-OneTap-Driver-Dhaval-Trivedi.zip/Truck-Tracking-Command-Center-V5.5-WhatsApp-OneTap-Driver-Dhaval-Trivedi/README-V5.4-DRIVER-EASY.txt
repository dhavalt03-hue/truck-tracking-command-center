Truck Tracking Command Center V5.4 — Driver Easy & Reliable

Changes from the chosen V5.3 Professional master:
- No driver login.
- Office WhatsApp/SMS link assigns the truck automatically.
- Link uses autostart=1: after one-time Android permissions, tracking starts automatically.
- First permission grant now continues the pending auto-start instead of requiring the driver to repeat the process.
- Driver still has a large START TRACKING button as a fallback.
- Driver cannot complete/cancel a trip; only the owner Command Center controls trip closing.
- Tracking remains requested with no time limit while the owner trip is ACTIVE.
- Foreground GPS stays visible in Android notification and can continue with the phone locked.
- START_STICKY + BootReceiver attempt to resume after app swipe/restart/phone reboot while desired_tracking is true.
- Temporary network loss does not close the trip; the service retries on later GPS updates.
- Existing V5.3 Professional owner features and Supabase structure are preserved.

Recommended first-phone setup:
1. Install APK once.
2. Open Reliability Setup and allow Location appropriately.
3. Set Battery to Unrestricted / allow background activity on Samsung/OEM phones.
4. Thereafter, normal driver action is: tap office WhatsApp link.

Made by Dhaval Trivedi
