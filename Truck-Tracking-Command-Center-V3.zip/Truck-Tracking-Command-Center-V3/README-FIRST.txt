TRUCK TRACKING COMMAND CENTER V3 — START HERE

WHAT YOU HAVE
1) owner-web/       = iPhone/PC live fleet dashboard
2) driver-android/  = native Android driver app source with locked-screen foreground GPS
3) SUPABASE_SETUP.sql = one-time database upgrade

YOUR EXISTING SUPABASE PROJECT IS ALREADY CONFIGURED IN BOTH PARTS.

FIRST
Run SUPABASE_SETUP.sql in Supabase SQL Editor.

OWNER
Deploy owner-web/index.html to the SAME Cloudflare worker you already created. Keep one workers.dev address and update that same worker when we release new versions.

DRIVER
The Android app must be compiled to an APK once using Android Studio. After installation, the driver only uses START TRIP / END TRIP.

PERMANENT LINK
Your Cloudflare workers.dev address stays the same as long as you keep that Worker/project and do not delete/rename it. You can later attach your own custom domain if desired.
