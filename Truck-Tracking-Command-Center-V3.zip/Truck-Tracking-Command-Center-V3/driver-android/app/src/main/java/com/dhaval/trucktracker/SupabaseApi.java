package com.dhaval.trucktracker;
import android.content.Context;import org.json.*;import java.io.*;import java.net.*;import java.nio.charset.StandardCharsets;import java.time.Instant;import java.util.*;
public class SupabaseApi {
  public static final String BASE="https://kdsbenbjvxzubpxuipvk.supabase.co";
  public static final String KEY="sb_publishable_6oPcc0apzZyXZfUgPp-gzA_aZuCqrmJ";
  private final Prefs prefs; public SupabaseApi(Context c){prefs=new Prefs(c);}
  private String read(InputStream is)throws Exception{BufferedReader r=new BufferedReader(new InputStreamReader(is,StandardCharsets.UTF_8));StringBuilder b=new StringBuilder();String s;while((s=r.readLine())!=null)b.append(s);return b.toString();}
  private String call(String method,String url,String body,String bearer)throws Exception{
    HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setRequestMethod(method);c.setConnectTimeout(20000);c.setReadTimeout(20000);c.setRequestProperty("apikey",KEY);c.setRequestProperty("Content-Type","application/json");if(bearer!=null)c.setRequestProperty("Authorization","Bearer "+bearer);if(body!=null){c.setDoOutput(true);try(OutputStream os=c.getOutputStream()){os.write(body.getBytes(StandardCharsets.UTF_8));}}
    int code=c.getResponseCode();String out=read(code>=200&&code<300?c.getInputStream():c.getErrorStream());if(code<200||code>=300)throw new IOException("HTTP "+code+" "+out);return out;
  }
  public boolean hasSession(){return !prefs.get("refresh","").isEmpty();}
  public synchronized String token()throws Exception{
    long exp=0;try{exp=Long.parseLong(prefs.get("expires","0"));}catch(Exception ignored){} long now=Instant.now().getEpochSecond();
    if(now<exp-120 && !prefs.get("access","").isEmpty())return prefs.get("access","");
    refresh();return prefs.get("access","");
  }
  private void saveAuth(JSONObject o)throws Exception{prefs.put("access",o.getString("access_token"));prefs.put("refresh",o.getString("refresh_token"));long sec=o.optLong("expires_in",3600);prefs.put("expires",String.valueOf(Instant.now().getEpochSecond()+sec));}
  public void login(String email,String password)throws Exception{JSONObject b=new JSONObject();b.put("email",email);b.put("password",password);saveAuth(new JSONObject(call("POST",BASE+"/auth/v1/token?grant_type=password",b.toString(),null)));}
  public void refresh()throws Exception{String r=prefs.get("refresh","");if(r.isEmpty())throw new IOException("Not signed in");JSONObject b=new JSONObject();b.put("refresh_token",r);saveAuth(new JSONObject(call("POST",BASE+"/auth/v1/token?grant_type=refresh_token",b.toString(),null)));}
  public JSONArray trucks()throws Exception{return new JSONArray(call("GET",BASE+"/rest/v1/Truck?select=id,truck_number,driver_name&order=created_at.asc",null,token()));}
  public void patchTruck(String id,JSONObject b)throws Exception{call("PATCH",BASE+"/rest/v1/Truck?id=eq."+URLEncoder.encode(id,"UTF-8"),b.toString(),token());}
}
