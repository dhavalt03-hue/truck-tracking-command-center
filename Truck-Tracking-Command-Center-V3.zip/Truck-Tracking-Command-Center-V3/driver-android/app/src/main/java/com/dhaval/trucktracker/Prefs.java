package com.dhaval.trucktracker;
import android.content.Context;import android.content.SharedPreferences;
public class Prefs {
  private final SharedPreferences p;
  public Prefs(Context c){p=c.getSharedPreferences("truck_tracker",Context.MODE_PRIVATE);}
  public void put(String k,String v){p.edit().putString(k,v).apply();} public String get(String k,String d){return p.getString(k,d);}
  public void putBool(String k,boolean v){p.edit().putBoolean(k,v).apply();} public boolean getBool(String k,boolean d){return p.getBoolean(k,d);}
  public void putFloat(String k,float v){p.edit().putFloat(k,v).apply();} public float getFloat(String k,float d){return p.getFloat(k,d);}
  public void clearSession(){p.edit().remove("access").remove("refresh").remove("expires").apply();}
}
