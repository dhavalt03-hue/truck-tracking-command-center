TRUCK TRACKER DRIVER — ANDROID V3 SOURCE

Purpose
- Driver signs in once, selects truck, presses START TRIP.
- App starts an Android foreground location service.
- A permanent notification stays visible while tracking is active.
- Driver may lock the phone; the service keeps sending GPS to Supabase.
- Access tokens are refreshed automatically using the Supabase refresh token.
- Driver presses END TRIP at destination.

Build
1. Install Android Studio on a computer.
2. Open the driver-android folder as a project.
3. Let Android Studio download the Android SDK/Gradle components.
4. Build > Build APK(s).
5. Install the APK on each driver's Android phone.

First phone setup
- Turn Location ON.
- Open the app and allow Precise Location.
- On phones with aggressive battery saving (Xiaomi/Oppo/Vivo/Realme etc.), set this app to Battery > Unrestricted / Don't optimize.
- Keep mobile data enabled during the trip.

Important
- This is a practical test build, not a Play Store production release.
- Android may still stop apps after a force-stop, OS update/reboot, or manufacturer-specific battery restrictions.
- Do not use hidden tracking. Drivers should know tracking is active; the foreground notification is intentionally permanent.
