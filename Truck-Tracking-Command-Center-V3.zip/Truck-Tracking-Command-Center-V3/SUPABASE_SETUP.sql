-- Truck Tracking Command Center V3
-- Run once in Supabase > SQL Editor.
-- This keeps your existing Truck table and adds V3 trip fields.

alter table public."Truck"
  add column if not exists distance_km double precision not null default 0,
  add column if not exists trip_started_at timestamptz,
  add column if not exists tracking_active boolean not null default false,
  add column if not exists last_accuracy_m double precision;

-- Existing authenticated SELECT / INSERT / UPDATE policies are enough for this test build.
-- For production, create per-driver ownership policies rather than allowing every authenticated
-- driver to update every truck.
