OWNER WEB V3
1. Run SUPABASE_SETUP.sql once in Supabase SQL Editor.
2. Upload the contents of owner-web to your existing Cloudflare Worker/static-assets project.
3. Open the workers.dev URL on iPhone Safari.
4. Sign in with a Supabase authenticated user.
5. Add trucks and watch locations sent by the Driver Android app.

The owner page itself does NOT send your iPhone GPS.
