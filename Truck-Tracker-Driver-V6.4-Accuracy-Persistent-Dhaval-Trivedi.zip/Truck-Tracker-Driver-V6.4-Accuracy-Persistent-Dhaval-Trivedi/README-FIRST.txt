Truck Tracker Driver V6.4 — Accuracy + Persistent Background GPS
Dhaval Trivedi

WHAT CHANGED FROM V6.3
- Keeps the same WhatsApp -> driver.html -> trucktracker://assign -> Android app flow.
- Tracking remains inside the installed Android app after handoff; Chrome is not the tracker.
- Uses Google Fused Location Provider in HIGH ACCURACY mode.
- Samples GPS about every 5 seconds while the foreground service is active.
- Sends faster while moving and slower while stopped.
- Filters GPS drift so a parked truck should report 0 km/h instead of false 1–2 km/h movement.
- Rejects very weak/stale fixes and avoids counting drift as trip KM.
- START_STICKY foreground service remains active when the app is backgrounded/phone locked.
- Adds a restart request if the app task is swiped away, plus the existing reboot receiver.
- Preserves the last accepted GPS locally; a temporary network error does not clear assignment or stop tracking.

IMPORTANT ANDROID SETUP
1. Install the APK.
2. Open the WhatsApp trip link; it hands the assignment to the Android app.
3. Tap START TRIP.
4. Allow Precise Location and Notifications.
5. Tap CHECK PHONE SETUP and set Battery to Unrestricted / Don't optimize.
6. If Android offers Location -> Allow all the time, enable it.
7. Keep device Location and mobile data ON.

The owner Command Centre is NOT changed by this package.
